/**
 * This program takes input of a triangle: two sides
 * and the angle between the two sides in radians. It
 * returns the value of the smallest angle in degrees.
 * Assumes that all input will follow the variable
 * input type it is supposed to be (double).
 *
 * Date: Feb. 8th, 2022
 * @author Jessica Lu
 */

import java.util.*;
import static java.lang.Math.*;

public class Lu_Jessica_SASTriangleSolver {
    public static void main(String[] args) {
        // variables
        Scanner sc = new Scanner(System.in);
        double sideA, sideB; // given input: side lengths
        double angleC; // given input: this is the angle between side 1 and side 2, opposite of side 3. in radians
        double sideC; // calculated using cos law
        double angleA, angleB; // calculated using cos law, in radians
        double smallestAngleInDeg; // smallest angle out of all 3, in degrees, rounds off the decimal

        // getting input of the triangle (2 sides and angle between them)
        System.out.print("Enter the length of side #1: ");
        sideA = sc.nextDouble();
        sc.nextLine(); // stops the "enter" from last input becoming the next input
        System.out.print("Enter the length of side #2: ");
        sideB = sc.nextDouble();
        sc.nextLine(); // stops the "enter" from last input becoming the next input
        System.out.print("Enter the angle between side #1 and #2 in radians: ");
        angleC = sc.nextDouble();

        sideC = cosineLawForSides(sideA, sideB, angleC); // calculate side C

        // calculate other angles in rad
        angleA = cosineLawForAngles(sideB, sideC, sideA);
        angleB = cosineLawForAngles(sideA, sideC, sideB);

        // output the smallest angle in degrees
        smallestAngleInDeg = smallestAngle(angleA, angleB, angleC);
        output(smallestAngleInDeg);
    }

    /**
     * Name: cosineLawForSides
     * Description: takes 2 sides and the angle between them and returns the side opposite of the angle in radians
     * @param sideA length of side A
     * @param sideB length of side B
     * @param angleC angle C in radians
     * @return side length opposite of angle C
     */
    public static double cosineLawForSides(double sideA, double sideB, double angleC) {
        // variables
        double sideC;

        // cosine law: c = sqrt(a^2 + b^2 - 2abcosC)
        sideC = sqrt(pow(sideA, 2) + pow(sideB, 2) - 2 * sideA * sideB * cos(angleC));

        return sideC;
    }

    /**
     * Name: cosineLawForAngles
     * Description: takes 3 sides and returns one of the angles in radians.
     * Using cosine law for this and not sine law to avoid ambiguity
     * @return one of the angle in radians
     */
    public static double cosineLawForAngles(double sideA, double sideB, double sideC) {
        // variables
        double angle; // opposite to side C (not sideC variable but the third parameter)

        // cosine law: c = sqrt(a^2 + b^2 - 2abcosC)
        // changed to find angle C:
        // acos is arccos (inverse)
        angle = acos((pow(sideA, 2) + pow(sideB, 2) - pow(sideC, 2))/(2 * sideA * sideB));

        return angle;
    }

    /**
     * Name: smallestAngle
     * Description: compares the three angles and returns which one is the smallest in degrees
     * @param angleA angle opposite of side a
     * @param angleB angle opposite of side b
     * @param angleC angle opposite of side c
     * @return smallest angle (of a, b and c) in degrees
     */
    public static double smallestAngle(double angleA, double angleB, double angleC) {
        // variables
        double smallestAngle; // between angle a, b, c, and in degrees

        // compares angle b and c and returns the smaller one, then compares that angle with angle a and returns that smallest one
        // changes it from rad to deg
        smallestAngle = Math.toDegrees(Math.min(angleA, Math.min(angleB, angleC)));

        return smallestAngle;
    }

    /**
     * Name: output
     * Description: outputs the smallest angle in degrees
     * @param angle the smallest angle in the triangle in degrees
     */
    public static void output(double angle) {
        System.out.println();
        System.out.printf("In degrees, the smallest angle is: %.0f\u00B0.", angle);
    }
}