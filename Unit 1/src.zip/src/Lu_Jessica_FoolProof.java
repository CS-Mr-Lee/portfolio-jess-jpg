/**
 * This program does division: it asks for the numerator
 * and divisor and outputs the quotient. If the user inputs
 * something invalid, it will tell them that it is invalid
 * (instead of crashing). The program terminates once the
 * numerator input starts with the letter: "q" or "Q".
 *
 * Date: Feb. 11th, 2022
 * @author Jessica Lu
 */

import java.util.*;

public class Lu_Jessica_FoolProof {
    public static void main(String[] args) {
        // variables and constants
        Scanner sc = new Scanner(System.in);
        final String stopInput = "q"; // if the numerator starts with this (lowercase or uppercase) then the program terminates
        double numerator, divisor;
        String numeratorString = ""; // input numerator
        String divisorString = ""; // input denominator
        double quotient;
        boolean stop; // true if numeratorString starts with stopInput ("q")

        do {
            try {
                // ask user for numerator
                System.out.print("Enter the numerator: ");
                numeratorString = sc.nextLine();
                stop = numeratorString.toLowerCase().startsWith(stopInput);
                numerator = Double.parseDouble(numeratorString);

                // if numerator doesn't start with a 'q' or 'Q', ask for denominator
                if (!numeratorString.equals(stopInput)) {
                    System.out.print("Enter the denominator: ");
                    divisorString = sc.nextLine();
                    divisor = Double.parseDouble(divisorString);

                    // if denominator is 0, output that you cannot divide by 0. if not, output the quotient
                    if (divisor == 0) {
                        System.out.println("You can't divide by 0!");
                    } else {
                        quotient = numerator / divisor;
                        System.out.println(numerator + " / " + divisor + " = " + quotient);
                    }
                    System.out.println();
                }
            } catch (IllegalArgumentException e) {
                stop = numeratorString.toLowerCase().startsWith(stopInput);

                // if the user does not want to stop (if the numerator does NOT start with q), output a data type error message
                if (!stop) {
                    System.out.println("You entered bad data.");
                    System.out.println("Please try again.\n");
                }
            }
        } while (!stop); // loop if user wants to keep going.
    }
}