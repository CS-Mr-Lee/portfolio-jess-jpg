/**
 * This program reads a file containing
 * League of Legends champion data and outputs:
 *     a) the name and hp of the champion with the highest hp
 *     b) the name and armor of the champion with the lowest armor
 * It writes in a file called "MaxChampStats.txt".
 * Date: Feb. 11th, 2022
 * @author Jessica Lu
 */

/*
highest hp: tryndamere (625.64 health)
lowest armor: orianna (17.04 armor)
 */

import java.io.*;

public class Lu_Jessica_ChampionFilter {
    public static void main(String[] args) {
        // variables
        String fileIn = "src\\champions.json";

        String name = ""; // name of champ
        double hp; // hp of champ
        double armor; // armor of champ

        String maxHpChamp = ""; // champ with max hp
        double maxHp = -2147483647; // max hp value, starts off as the lowest integer stored possible
        String minArmorChamp = ""; // champ with min armor
        double minArmor = 2147483647; // min armor value, starts off as the highest integer stored possible

        // try-with-resources (automatically closes the reader)
        // https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html
        try (BufferedReader br = new BufferedReader(new FileReader(fileIn))) {
            String line;

            // below is so weird
            boolean firstChamp = true;

            while ((line = br.readLine()) != null) { // loops until there is no more!
                // reads in the name
                if (line.contains("\"name\"")) {
                    String[] nameLine = line.split(": \""); // splits the '"name": 'and '"champName",'
                    String nameValue = nameLine[1]; // nameValue = '"champName",'
                    name = nameValue.substring(0, nameValue.length() - 2); // cuts off the last '",' so it only takes the name itself
                }

                // reads in the hp and compares it with the highest hp so far
                // if the hp read in is higher than the highest hp, that becomes the new highest hp
                if (line.contains("\"hp\"")) {
                    String[] hpLine = line.split(": "); // split the line
                    String hpValue = hpLine[1]; // hpValue = 'number,'
                    hp = Double.parseDouble(hpValue.substring(0, hpValue.length() - 1)); // cuts off the end of the line and casts the value from a string to a double

                    // if this hp is higher than the max hp then declare the new hp as the one with highest max hp
                    if (hp > maxHp) {
                        maxHp = hp;
                        maxHpChamp = name;
                    }
                }

                // reads in the armor and compares it with the lowest hp so far
                // if the armor read in is lower than the lowest hp, that becomes the new lowest hp
                if (line.contains("\"armor\"")) {
                    String[] armorLine = line.split(": "); // split the line
                    String armorValue = armorLine[1]; // hpValue = 'number,'
                    armor = Double.parseDouble(armorValue.substring(0, armorValue.length() - 1)); // cuts off the end of the line and casts the value from a string to a double

                    // if this armor is less than the min armor then declare the new armor as the one with lowest max hp
                    if (armor < minArmor) {
                        minArmor = armor;
                        minArmorChamp = name;
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("file IO exception");
        }

        writeToFile(maxHp, maxHpChamp, minArmor, minArmorChamp);
    }

    public static void writeToFile(double hp, String hpChamp, double armor, String armorChamp) {
        // variables
        String file = "MaxChampStats.txt";

        // try-with-resources ; auto closes the fileWriter
        try (FileWriter fw = new FileWriter(file)) {
            // writes the champ with max hp and that value and the champ with min armor and that value
            fw.write("champion with max hp: " + hpChamp + "\n");
            fw.write("hp value: " + hp+ "\n");
            fw.write("\n");
            fw.write("champion with min armor: " + armorChamp+ "\n");
            fw.write("armor value: " + armor+ "\n");
        } catch (IOException e) {
            System.out.println("io exception!!");
        }
    }
}
