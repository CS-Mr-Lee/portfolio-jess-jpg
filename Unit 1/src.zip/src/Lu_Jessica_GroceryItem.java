/**
 * This program takes input of two item names and two prices,
 * making sure that the name length is less than a value
 * and that the price does not exceed another value.
 *
 * Date: Feb. 8th, 2022
 * @author Jessica Lu
 */

// EVERYTHING IS DONE EXCEPT:
// must fix the output; the formatting is poor and incorrect!

import java.util.*;

public class Lu_Jessica_GroceryItem {

    public static void main(String[] args) {
        // variables
        Scanner sc = new Scanner(System.in);
        String name1;
        String name2;
        double price1;
        double price2;

        // gets item 1 name and price
        System.out.println("ITEM ONE (1)");
        name1 = getItemName();
        price1 = getItemPrice();

        // gets item 2 name and price
        System.out.println();
        System.out.println("ITEM TWO (2)");
        name2 = getItemName();
        price2 = getItemPrice();

        sc.close();

        // output
        output(name1, price1, name2, price2);
    }

    /**
     * Name: getItemName
     * Description: gets item name
     * @return the name of the item
     */
    public static String getItemName() {
        // variables
        Scanner sc = new Scanner(System.in);
        String name;
        boolean goodCharLength;

        do {
            System.out.println("What is the name of this item?");
            name = sc.nextLine();
            goodCharLength = checkCharLength(name); // true if input name character length does not exceed max char limit

            // outputs if the input is invalid
            if (!goodCharLength) {
                System.out.println("Sorry, that item name exceeds the character limit.");
                System.out.println();
            }
        } while (!goodCharLength); // loops until the input character count is valid (<= char limit)

        return name; // returns item name in valid form
    }

    /**
     * Name: getItemPrice
     * Description: gets item price
     * @return the price of the item
     */
    public static double getItemPrice() {
        // variables
        Scanner sc = new Scanner(System.in);
        double price = -1;
        boolean goodPrice = false;

        // loops until price is valid (non-negative and doesn't exceed max price)
        do {
            // makes sure the input is a number
            try {
                System.out.println("What is the price of the item?");
                price = sc.nextDouble();
                sc.nextLine();

                goodPrice = checkPrice(price); // true if input price is valid (not non-negative and does not exceed max price)

                // outputs if the input is invalid
                if (!goodPrice) {
                    System.out.println("Sorry, that price is invalid.");
                    System.out.println("Make sure your entered value is non-negative and does not exceed the price limit.");
                    System.out.println();
                }
            } catch (InputMismatchException e) {
                sc.nextLine();
                System.out.println("That's not a number!");
                System.out.println();
            }
        } while (!goodPrice); // while input price is invalid

        return price; // returns item price in valid form
    }

    /**
     * Name: checkCharLength
     * Description: gets item name and makes sure input does not exceed 20 character count
     * @param name the item name input
     * @return if the input is valid
     */
    public static boolean checkCharLength(String name) {
        // variables and constants
        final int maxCharCount = 20; // given max character input count
        boolean goodCharCount; // true if character input count is <= max length

        // checks the character length of input
        if (name.length() <= maxCharCount) {
            goodCharCount = true; // input length is less than max character count (valid input)
        } else {
            goodCharCount = false; // input length is more than max character count (invalid input)
        }

        return goodCharCount;
    }

    /**
     * Name: checkPrice
     * Description: gets item price and makes sure input does not exceed $99.99 and is not negative
     * @param price the item price input
     * @return if the input is valid
     */
    public static boolean checkPrice(double price) {
        // variables and constants
        final double maxPrice = 99.99; // given max price value
        boolean goodPrice; // true if input price is <= max price

        // checks price value
        if (price < 0) { // negative input
            goodPrice = false; // price is negative (invalid input)
        } else { // non-negative input, checking if it is in range
            if (price <= maxPrice) {
                goodPrice = true; // price is <= max price (valid input)
            } else {
                goodPrice = false; // price is > max price (invalid input)
            }
        }
        return goodPrice;
    }

    /**
     * Name: output
     * Description: outputs the item names and prices
     * @param name1 the name of item 1
     * @param price1 the name of price 1
     * @param name2 the name of item 2
     * @param price2 the name of price 2
     */
    public static void output(String name1, double price1, String name2, double price2) {
        final int regularSpaces = 22; // for 4 character length price (there is 5 if it is 10 or more, 4 if below)
        int space1, space2; // different # spaces for line 1 and line 2

        // assigning a value to how many spaces should be between the name and price, depends on the length of the price.
        if (price1 < 10) {
            space1 = regularSpaces;
        } else {
            space1 = regularSpaces - 1;
        }

        // same as above but for second line
        if (price2 < 10) {
            space2 = regularSpaces;
        } else {
            space2 = regularSpaces - 1;
        }

        // output receipt
        System.out.println("---------------------------");
        System.out.printf("%-" + space1 + "s$%.2f%n", name1, price1);
        System.out.printf("%-" + space2 + "s$%.2f%n", name2, price2);
        System.out.println("---------------------------");
    }

}

