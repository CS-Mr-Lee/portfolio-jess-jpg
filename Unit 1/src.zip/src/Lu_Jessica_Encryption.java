/**
 * This program encrypts a line of code.
 * -> First and last character of each word are exchanged
 * -> Middle characters of each word are shifted to the character two after it in the ASCII table
 * -> Spaces do not change
 *
 * Date: Feb. 10th, 2022
 * @author Jessica Lu
 */

import java.util.*;

public class Lu_Jessica_Encryption {
    public static void main(String[] args) {
        // variables
        Scanner sc = new Scanner(System.in);
        String input; // input sentence
        String[] splitWords; // stores separate words: splits the input into separate words (based on " " spaces)

        // get input and store each split word into an array
        System.out.println("Enter a sentence:");
        input = sc.nextLine();
        splitWords = input.split(" "); // splits the array on "spaces" (between words)

        // swaps first and last, repeats for all the words
        int i; // counter
        for (i = 0; i < splitWords.length; i++) {
            swapCharacters(splitWords[i]);
        }
    }

    /**
     * Name: swapCharacters
     * Description: swaps the first and last characters around. the middle characters are
     * shifted two after it in the ASCII table. outputs the swapped words.
     */
    public static void swapCharacters(String word) {
        // ok now u have one word and u just swap the first and last character around
        // variables
        int wordLength; // # of characters in the word
        char[] newWordArray; // char array of new word
        String newWord; // swapped first and last characters around
        char storeChar; // singular character stored

        newWordArray = word.toCharArray(); // save the word as a char array
        wordLength = word.length(); // get length of the word

        // swap the first and last characters around by saving that character in a different (char) variable
        storeChar = word.charAt(0); // get the first character of the word
        newWordArray[wordLength - 1] = storeChar; // store that character into the last place of the new word
        storeChar = word.charAt(wordLength - 1); // get last character of the word
        newWordArray[0] = storeChar; // store that character in the first place of the new word

        // shift every character between the first and last by +2 in the ASCII table
        int i;
        for (i = 1; i < wordLength - 1; i++) { // loop for every character between the first and last
            newWordArray[i] = (char)(newWordArray[i] + 2);
        }

        // convert char array back to a string
        newWord = String.valueOf(newWordArray);

        // print out the word and a space " "
        System.out.print(newWord + " ");
    }
}